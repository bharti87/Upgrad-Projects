-- Stock market analysis

-- Creating assignemt schema
create schema assignment;

-- Using assignment schema
use assignment;

-- All the CSV files have been imported using table data import wizard
-- Only 'Date' and 'Close Price' columns have been imported as is 
-- as only those are required for further manipulation of stocks.

desc bajaj_auto;
select * from bajaj_auto limit 5;

desc eicher_motors;
select * from eicher_motors limit 5;

desc hero_motocorp;
select * from hero_motocorp limit 5;

desc infosys;
select * from infosys limit 5;

desc tcs;
select * from tcs limit 5;

desc tvs_motors;
select * from tvs_motors limit 5;

-- Changing the 'date' column format from string to date format for all the above tables for all the six stocks.

UPDATE `bajaj_auto`
SET `date` = STR_TO_DATE(`date`,'%d-%M-%Y');
alter table `bajaj_auto` modify column `date` date;

UPDATE `eicher_motors`
SET `date` = STR_TO_DATE(`date`,'%d-%M-%Y');
alter table `eicher_motors` modify column `date` date;

UPDATE `hero_motocorp`
SET `date` = STR_TO_DATE(`date`,'%d-%M-%Y');
alter table `hero_motocorp` modify column `date` date;

UPDATE `infosys`
SET `date` = STR_TO_DATE(`date`,'%d-%M-%Y');
alter table `infosys` modify column `date` date;

UPDATE `tcs`
SET `date` = STR_TO_DATE(`date`,'%d-%M-%Y');
alter table `tcs` modify column `date` date;

UPDATE `tvs_motors`
SET `date` = STR_TO_DATE(`date`,'%d-%M-%Y');
alter table `tvs_motors` modify column `date` date;

/*Create a new table named 'bajaj1' containing the date, close price, 20 Day MA and 50 Day MA.*/

create table `bajaj1` as 
select  `Date`,`Close Price`,
if((ROW_NUMBER() OVER w) > 19, (avg(`Close Price`) OVER (order by `date` asc rows 19 PRECEDING)), null) `20 Day MA`,
if((ROW_NUMBER() OVER w) > 49, (avg(`Close Price`) OVER (order by `date` asc rows 49 PRECEDING)), null) `50 Day MA`
from `bajaj_auto`
window w as (order by `date` asc);

select * from `bajaj1` limit 100;

/*Create a new table named 'eicher1' containing the date, close price, 20 Day MA and 50 Day MA.*/

create table `eicher1` as 
select  `Date`,`Close Price`,
if((ROW_NUMBER() OVER w) > 19, (avg(`Close Price`) OVER (order by `date` asc rows 19 PRECEDING)), null) `20 Day MA`,
if((ROW_NUMBER() OVER w) > 49, (avg(`Close Price`) OVER (order by `date` asc rows 49 PRECEDING)), null) `50 Day MA`
from `eicher_motors`
window w as (order by `date` asc);

select * from `eicher1` limit 100;

/*Create a new table named 'hero1' containing the date, close price, 20 Day MA and 50 Day MA.*/

create table `hero1` as 
select  `Date`,`Close Price`,
if((ROW_NUMBER() OVER w) > 19, (avg(`Close Price`) OVER (order by `date` asc rows 19 PRECEDING)), null) `20 Day MA`,
if((ROW_NUMBER() OVER w) > 49, (avg(`Close Price`) OVER (order by `date` asc rows 49 PRECEDING)), null) `50 Day MA`
from `hero_motocorp`
window w as (order by `date` asc);

select * from `hero1` limit 100;

/*Create a new table named 'infosys1' containing the date, close price, 20 Day MA and 50 Day MA.*/

create table `infosys1` as 
select  `Date`,`Close Price`,
if((ROW_NUMBER() OVER w) > 19, (avg(`Close Price`) OVER (order by `date` asc rows 19 PRECEDING)), null) `20 Day MA`,
if((ROW_NUMBER() OVER w) > 49, (avg(`Close Price`) OVER (order by `date` asc rows 49 PRECEDING)), null) `50 Day MA`
from `infosys`
window w as (order by `date` asc);

select * from `infosys1` limit 100;

/*Create a new table named 'tcs1' containing the date, close price, 20 Day MA and 50 Day MA.*/

create table `tcs1` as 
select  `Date`,`Close Price`,
if((ROW_NUMBER() OVER w) > 19, (avg(`Close Price`) OVER (order by `date` asc rows 19 PRECEDING)), null) `20 Day MA`,
if((ROW_NUMBER() OVER w) > 49, (avg(`Close Price`) OVER (order by `date` asc rows 49 PRECEDING)), null) `50 Day MA`
from `tcs`
window w as (order by `date` asc);

select * from `tcs1` limit 100;

/*Create a new table named 'tvs1' containing the date, close price, 20 Day MA and 50 Day MA.*/

create table `tvs1` as 
select  `Date`,`Close Price`,
if((ROW_NUMBER() OVER w) > 19, (avg(`Close Price`) OVER (order by `date` asc rows 19 PRECEDING)), null) `20 Day MA`,
if((ROW_NUMBER() OVER w) > 49, (avg(`Close Price`) OVER (order by `date` asc rows 49 PRECEDING)), null) `50 Day MA`
from `tvs_motors`
window w as (order by `date` asc);

select * from `tvs1` limit 100;

/* Creating a master table containing the date and close price of all the six stocks. 
(Column header for the price is the name of the stock)*/

create table master_table as 
select b.date as `Date`, 
b.`Close Price` as `Bajaj`, 
tc.`Close Price` as `TCS`,
tv.`Close Price` as `TVS`,
i.`Close Price` as `Infosys`,
e.`Close Price` as `Eicher`,
h.`Close Price` as `Hero`
from bajaj1 b 
inner join tcs1 tc on tc.date = b.date
inner join tvs1 tv on tv.date = tc.date
inner join infosys1 i on i.date = tv.date
inner join eicher1 e on e.date = i.date
inner join hero1 h on h.date = e.date;

-- check the master_table data
select * from master_table limit 50;

-- For analysis purpose
select min(bajaj) , max(Bajaj) as b from master_table
union 
select min(TCS) , max(TCS) from master_table
union
select min(TVS) , max(TVS) from master_table
union 
select min(Infosys) , max(Infosys) from master_table
union 
select min(Eicher) , max(Eicher) from master_table
union 
select min(Hero) , max(Hero) from master_table;

/* Generating buy and sell signal for all the six stocks and store them in new tables.*/

-- For bajaj stock
create table bajaj2 as 
SELECT `Date`, `Close Price`,
case 
        WHEN `20 Day MA` > `50 Day MA` AND LAG(`20 Day MA`) over() < LAG(`50 Day MA`) over() THEN 'BUY'
		WHEN `20 Day MA` < `50 Day MA` AND LAG(`20 Day MA`) over() > LAG(`50 Day MA`) over() THEN 'SELL'
		ELSE 'HOLD' 
end as `Signal`
FROM bajaj1;

-- For analysis purpose
select * from `bajaj2` where `Signal` like 'BUY' or `Signal` like 'SELL';

-- For eicher stock
create table eicher2 as 
SELECT `Date`, `Close Price`,
case 
        WHEN `20 Day MA` > `50 Day MA` AND LAG(`20 Day MA`) over() < LAG(`50 Day MA`) over() THEN 'BUY'
		WHEN `20 Day MA` < `50 Day MA` AND LAG(`20 Day MA`) over() > LAG(`50 Day MA`) over() THEN 'SELL'
		ELSE 'HOLD' 
end as `Signal`
FROM eicher1;

-- For hero stock
create table hero2 as 
SELECT `Date`, `Close Price`,
case 
        WHEN `20 Day MA` > `50 Day MA` AND LAG(`20 Day MA`) over() < LAG(`50 Day MA`) over() THEN 'BUY'
		WHEN `20 Day MA` < `50 Day MA` AND LAG(`20 Day MA`) over() > LAG(`50 Day MA`) over() THEN 'SELL'
		ELSE 'HOLD' 
end as `Signal`
FROM hero1;

-- For infosys stock
create table infosys2 as 
SELECT `Date`, `Close Price`,
case 
        WHEN `20 Day MA` > `50 Day MA` AND LAG(`20 Day MA`) over() < LAG(`50 Day MA`) over() THEN 'BUY'
		WHEN `20 Day MA` < `50 Day MA` AND LAG(`20 Day MA`) over() > LAG(`50 Day MA`) over() THEN 'SELL'
		ELSE 'HOLD' 
end as `Signal`
FROM infosys1;

-- For TCS stock
create table tcs2 as 
SELECT `Date`, `Close Price`,
case 
        WHEN `20 Day MA` > `50 Day MA` AND LAG(`20 Day MA`) over() < LAG(`50 Day MA`) over() THEN 'BUY'
		WHEN `20 Day MA` < `50 Day MA` AND LAG(`20 Day MA`) over() > LAG(`50 Day MA`) over() THEN 'SELL'
		ELSE 'HOLD' 
end as `Signal`
FROM tcs1;

-- For TVS stock
create table tvs2 as 
SELECT `Date`, `Close Price`,
case 
        WHEN `20 Day MA` > `50 Day MA` AND LAG(`20 Day MA`) over() < LAG(`50 Day MA`) over() THEN 'BUY'
		WHEN `20 Day MA` < `50 Day MA` AND LAG(`20 Day MA`) over() > LAG(`50 Day MA`) over() THEN 'SELL'
		ELSE 'HOLD' 
end as `Signal`
FROM tvs1;

/* Creating a User defined function, 
that takes the date as input and returns the signal for that particular day (Buy/Sell/Hold) 
for the Bajaj stock.
*/
DROP function IF EXISTS assignment.GetSignal_Bajaj;

create function GetSignal_Bajaj(in_date date)
returns char(4) deterministic
return (select `Signal` from `bajaj2` where `date`=in_date);

/* Generating a signal by calling the UDF for bajaj stock */

Select GetSignal_Bajaj('2018-07-25'); 
Select GetSignal_Bajaj('2015-01-01'); 
Select GetSignal_Bajaj('2016-04-08'); 
Select GetSignal_Bajaj('2017-12-22'); 









